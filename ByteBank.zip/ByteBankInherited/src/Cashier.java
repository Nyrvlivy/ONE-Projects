public class Cashier extends Employee {
    //Attributes

    // Constructors
    public Cashier() {
    }
    // Methods
    public double getBonusPayment(){
        return super.getBonusPayment() + 100;
    }

    // Methods Getter and Setter
    }

