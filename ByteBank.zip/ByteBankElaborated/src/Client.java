public class Client {
    // Attributes
    String name;
    String cpf;
    String profession;

    // Methods


}
